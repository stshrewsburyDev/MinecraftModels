# Monitor model
### Created by Steven Shrewsbury (stshrewsburyDev)

Website page (with more info on model):
-------------
https://models.stshrewsbury.dev

How to download:
----------------
Just select the file named `monitor.zip` and hit `download` on the preview.

Credit:
-------
Credit is appreciated.

Links:
------
* [GitHub](https://github.com/stshrewsburyDev/)
* [Twitter](https://twitter.com/stshrewsburyDev/)
* [My website](https://stshrewsburydev.github.io/)
* [Steven Shrewsbury - Minecraft models](https://models.stshrewsbury.dev/)
a
